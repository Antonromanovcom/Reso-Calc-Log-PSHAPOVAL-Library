CREATE VIEW AE_PRICES AS select version_id,spare_id,raion_id,price from osago_001.ae_prices
union all
select version_id,spare_id,raion_id,price from osago_002.ae_prices
union all
select version_id,spare_id,raion_id,price from osago_003.ae_prices
union all
select version_id,spare_id,raion_id,price from osago_004.ae_prices
union all
select version_id,spare_id,raion_id,price from osago_005.ae_prices
union all
select version_id,spare_id,raion_id,price from osago_006.ae_prices
union all
select version_id,spare_id,raion_id,price from osago_007.ae_prices
union all
select 8 as version_id,spare_id,raion_id,price from osago_008.ae_prices
union all
select version_id,spare_id,raion_id,price from osago_009.ae_prices
/
