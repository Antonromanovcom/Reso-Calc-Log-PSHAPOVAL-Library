CREATE VIEW AE_RAIONS AS select version_id,id,name from osago_001.AE_RAIONS
union all
select version_id,id,name from osago_002.AE_RAIONS
union all
select version_id,id,name from osago_003.AE_RAIONS
union all
select version_id,id,name from osago_004.AE_RAIONS
union all
select version_id,id,name from osago_005.AE_RAIONS
union all
select version_id,id,name from osago_006.AE_RAIONS
union all
select version_id,id,name from osago_007.AE_RAIONS
union all
select version_id,id,name from osago_008.AE_RAIONS
union all
select version_id,id,name from osago_009.AE_RAIONS
/
