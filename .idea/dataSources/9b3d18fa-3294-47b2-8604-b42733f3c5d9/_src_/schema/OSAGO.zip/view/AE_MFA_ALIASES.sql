CREATE VIEW AE_MFA_ALIASES AS select version_id,name,mfa_id from osago_001.AE_MFA_ALIASES
union all
select version_id,name,mfa_id from osago_002.AE_MFA_ALIASES
union all
select version_id,name,mfa_id from osago_003.AE_MFA_ALIASES
union all
select version_id,name,mfa_id from osago_004.AE_MFA_ALIASES
union all
select version_id,name,mfa_id from osago_005.AE_MFA_ALIASES
union all
select version_id,name,mfa_id from osago_006.AE_MFA_ALIASES
union all
select version_id,name,mfa_id from osago_007.AE_MFA_ALIASES
union all
select version_id,name,mfa_id from osago_008.AE_MFA_ALIASES
union all
select version_id,name,mfa_id from osago_009.AE_MFA_ALIASES
/
