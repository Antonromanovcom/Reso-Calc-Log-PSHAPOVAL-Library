CREATE VIEW V_BLOCKING_TREE AS select bl.blocking_tree "TREE"
,      ps.serial#
,      ps.os_pid
,      ps.username
,      ps.osuser
,      ps.terminal
,      ps.program
,      ps.status
,      ps.last_call
,      ps.obj
,      ps.sql_id
,      ps.prev_sql_id
,      ps.row_wait_obj#
,      ps.row_wait_file#
,      ps.row_wait_block#
,      ps.row_wait_row#
,      ps.event
,      ps.p1text
,      ps.p1
,      ps.p1raw
,      ps.p2text
,      ps.p2
,      ps.p2raw
,      ps.p3text
,      ps.p3
,      ps.p3raw
,      ps.sql_hash_value
,      ps.sql_address
,      ps.prev_hash_value
,      ps.prev_sql_addr
,      ps.module
,      ps.action
,      ps.wait_class
,      ps.seconds_in_wait
,      ps.state
,      ps.sid
from
(select rownum rn, blocking_tree,locked from (with locks as (select blocking_session locker , sid locked from v$session
     where blocking_session is not null)
SELECT LPAD(locked, LENGTH(locked)+(level*5-5), ' ') blocking_tree, locked
FROM   (SELECT * FROM locks
        UNION
        SELECT NULL, locker
        FROM locks
        WHERE locker NOT IN (SELECT locked FROM locks))
CONNECT BY PRIOR locked = locker
START WITH locker IS NULL)) bl,
(select  s.sid
,       s.serial#
,       p.spid "OS_PID"
,       s.username
,       s.osuser
,       s.terminal
,       s.program
,       s.status
,       SYSDATE - (s.last_call_et / 86400) last_call
, case s.event
   when 'enq: TM - contention' then (select ob.owner || '.' || ob.object_name
                   from dba_objects ob where ob.object_id= s.P2)
   when 'enq: TX - row lock contention' then (select ob.owner || '.' || ob.object_name ||' / '||
                   sys.dbms_rowid.rowid_create(1, ob.data_object_id,
                   s.row_wait_file#, s.row_wait_block#, s.row_wait_row#)
                   from dba_objects ob where ob.object_id(+)=s.row_wait_obj#)
 end obj
,       s.row_wait_obj#
,       s.row_wait_file#
,       s.row_wait_block#
,       s.row_wait_row#
,       s.event
,       s.p1text
,       s.p1
,       s.p1raw
,       s.p2text
,       s.p2
,       s.p2raw
,       s.p3text
,       s.p3
,       s.p3raw
,       s.sql_id
,       s.sql_address
,       s.sql_hash_value
,       s.prev_sql_id
,       s.prev_hash_value
,       s.prev_sql_addr
,       s.module
,       s.action
,       s.wait_class
,       s.seconds_in_wait
,       s.state
from    v$session s
,       v$process p
Where   s.paddr = p.addr
order   by status,username) ps
where bl.locked=ps.sid
order by bl.rn
/
