CREATE VIEW AE_MANUFACTURERS AS select version_id,id,name,brand_id,parent_id from osago_001.AE_MANUFACTURERS
union all
select version_id,id,name,brand_id,parent_id from osago_002.AE_MANUFACTURERS
union all
select version_id,id,name,brand_id,parent_id from osago_003.AE_MANUFACTURERS
union all
select version_id,id,name,brand_id,parent_id from osago_004.AE_MANUFACTURERS
union all
select version_id,id,name,brand_id,parent_id from osago_005.AE_MANUFACTURERS
union all
select version_id,id,name,brand_id,parent_id from osago_006.AE_MANUFACTURERS
union all
select version_id,id,name,brand_id,parent_id from osago_007.AE_MANUFACTURERS
union all
select version_id,id,name,brand_id,parent_id from osago_008.AE_MANUFACTURERS
union all
select version_id,id,name,brand_id,parent_id from osago_009.AE_MANUFACTURERS
/
