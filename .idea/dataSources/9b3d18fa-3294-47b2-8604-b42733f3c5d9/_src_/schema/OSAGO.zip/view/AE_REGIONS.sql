CREATE VIEW AE_REGIONS AS select version_id,id,name,code,raion_id from osago_001.AE_REGIONS
union all
select version_id,id,name,code,raion_id from osago_002.AE_REGIONS
union all
select version_id,id,name,code,raion_id from osago_003.AE_REGIONS
union all
select version_id,id,name,code,raion_id from osago_004.AE_REGIONS
union all
select version_id,id,name,code,raion_id from osago_005.AE_REGIONS
union all
select version_id,id,name,code,raion_id from osago_006.AE_REGIONS
union all
select version_id,id,name,code,raion_id from osago_007.AE_REGIONS
union all
select version_id,id,name,code,raion_id from osago_008.AE_REGIONS
union all
select version_id,id,name,code,raion_id from osago_009.AE_REGIONS
/
